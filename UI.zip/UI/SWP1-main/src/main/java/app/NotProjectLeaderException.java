package app;

public class NotProjectLeaderException extends Exception{

    /**
     * Generated a default serial version unique ID
     */
    private static final long serialVersionUID = -999567456944001210L;

    public NotProjectLeaderException(String errorMessage) {
        super(errorMessage);
    }
}
